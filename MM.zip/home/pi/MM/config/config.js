/* Magic Mirror Config Sample
 *
 * By Michael Teeuw http://michaelteeuw.nl
 * MIT Licensed.
 *
 * For more information how you can configurate this file
 * See https://github.com/MichMich/MagicMirror#configuration
 *
 */

var config = {
	address: "0.0.0.0", // Address to listen on, can be:
	                      // - "localhost", "127.0.0.1", "::1" to listen on loopback interface
	                      // - another specific IPv4/6 to listen on a specific interface
	                      // - "", "0.0.0.0", "::" to listen on any interface
	                      // Default, when address config is left out, is "localhost"
	port: 8080,
	ipWhitelist: [], // Set [] to allow all IP addresses
	                                                       // or add a specific IPv4 of 192.168.1.5 :
	                                                       // ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.1.5"],
	                                                       // or IPv4 range of 192.168.3.0 --> 192.168.3.15 use CIDR format :
	                                                       // ["127.0.0.1", "::ffff:127.0.0.1", "::1", "::ffff:192.168.3.0/28"],

	language: "en",
	timeFormat: 24,
	units: "metric",
	// serverOnly:  true/false/"local" ,
			     // local for armv6l processors, default 
			     //   starts serveronly and then starts chrome browser
			     // false, default for all  NON-armv6l devices
			     // true, force serveronly mode, because you want to.. no UI on this device
	
	modules: [
		{
			module: "alert",
		},
		{
			  module: 'MMM-TextPerWeek',
			  position: 'top_left',
			  header: 'To Do List',
			  config: {
			    texts: {
			      'default': '1. ,<br>2. ,<br>3. ,<br>4. ,<br>5. ,'
		    		}
		  	}
		},
		{
			module: "updatenotification",
			position: "top_bar"
		},
		{
			module: "clock",
			position: "top_center"
		},
		{
			module: "calendar",
			header: "Calendar",
			position: "top_left",
			config: {
				calendars: [
					{
						symbol: "calendar-check",
						url: "https://calendar.google.com/calendar/ical/dhiyaaabhirama4%40gmail.com/private-44e32d1d891f24ebad6ce34322088c4b/basic.ics"					}
				]
			}
		},
		{
			module: "compliments",
			position: "lower_third"
		},
		{
			module: "currentweather",
			position: "top_bar",
			config: {
				location: "Jakarta, Indonesia",
				locationID: "1642911",  //ID from http://bulk.openweathermap.org/sample/city.list.json.gz; unzip the gz file and find your city
				appid: "2a0fc9df77826a7e3459d434a0918d7b"
			}
		},
		{
			module: "weatherforecast",
			position: "bottom_right",
			header: "Weather Forecast",
			config: {
				location: "Jakarta, Indonesia",
				locationID: "1642911",  //ID from http://bulk.openweathermap.org/sample/city.list.json.gz; unzip the gz file and find your city
				appid: "2a0fc9df77826a7e3459d434a0918d7b"
			}
		},
		{
			module: "newsfeed",
			position: "bottom_bar",
			config: {
				feeds: [
					{
						title: "Detik",
						//url: "http://rss.cnn.com/rss/edition_world.rss"
						url: "https://rss.detik.com/"					
					}
				],
				showSourceTitle: true,
				showPublishDate: true,
				broadcastNewsFeeds: true,
				broadcastNewsUpdates: true
			}
		},
		{
			module: 'MMM-TweetsByTimelineOrList',
			position: 'bottom_right',
			header: "Twitter",
			config: {
			// visit the url below for the twitter keys/tokens
			// https://dev.twitter.com/oauth/overview/application-owner-access-tokens
				consumer_key: 'YAVwzMmCUJDIHxT03uwytiYMt',
				consumer_secret: 'gW09XOTIeZRueyNQknwGNaPhc7etwlK0tMksdGao27gizcNTcb',
				access_token_key: '464552756-As1fIY5J5enQJsZ8NDoCQldzuCAYgd28XnTfofkt',
				access_token_secret: 'xCumSQiPjUkJVzhw5b4ZHDmxz8eYFmFY3yT7U8g6Iqst1',
			// set the username and either timeline or listname
			screenName: 'someusername',
			listToShow: 'TIMELINE',
			}
		},
		{
			module: 'MMM-Remote-Control'
			// uncomment the following line to show the URL of the remote control on the mirror
			 //, position: 'bottom_left'
			// you can hide this module afterwards from the remote control itself
		},
		{
			module: 'email',
		        position: 'bottom_left',
		        header: 'Email',
		        config: {
		            accounts: [
		                {
		                    user: 'icrywolff@gmail.com',
		                    password: 'carlsberg11',
		                    host: 'imap.gmail.com',
		                    port: 993,
				    tls: true,
				    ssl: true,
		                    authTimeout: 10000,
		                    numberOfEmails: 5,
		                }
		            ],
		            fade: false,
		            maxCharacters: 30
		        }
		},
	]

};

/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== "undefined") {module.exports = config;}
