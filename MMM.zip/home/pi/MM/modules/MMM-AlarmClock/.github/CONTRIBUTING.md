# Contribution Guidelines

Thanks for contributing to this module!

Please create pull requests to the branch `develop`.

To hold one code style and standard there are several linters and tools in this project set. Make sure you fullfill the requirements.
Also there will be automatically analysis performed once you created the pull request.
